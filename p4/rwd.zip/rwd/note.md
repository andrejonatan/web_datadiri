insert into mahasiswa (nim, nama, umur, jurusan)
values (001, 'andrean', 19, 'TI');
values (002, 'kvara', 24, 'TI');
values (003, 'isak', 27, 'BD');
values (004, 'rayan', 22, 'SI');

