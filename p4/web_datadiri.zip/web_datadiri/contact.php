<?php
$githubUrl = $profile['github_url'] ?? '';
$instagramUrl = $profile['instagram_url'] ?? '';
$emailUser = $user['email'] ?? '';
$gmailLink = $emailUser ? ('mailto:' . $emailUser) : '';
?>

<div class="card">
  <div class="card-header app-header">Contact</div>
  <div class="card-body">

    <div class="list-group">
      <a class="list-group-item list-group-item-action d-flex align-items-center justify-content-between" href="<?= htmlspecialchars($githubUrl ?: '#') ?>" target="_blank" rel="noopener">
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-github"></i>
          <span>GitHub</span>
        </div>
        <span class="text-muted" style="font-size:.9rem;"><?= htmlspecialchars($githubUrl ?: '-https://github.com/andrejonatan') ?></span>
      </a>

      <a class="list-group-item list-group-item-action d-flex align-items-center justify-content-between" href="<?= htmlspecialchars($instagramUrl ?: '#') ?>" target="_blank" rel="noopener">
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-instagram"></i>
          <span>Instagram</span>
        </div>
        <span class="text-muted" style="font-size:.9rem;"><?= htmlspecialchars($instagramUrl ?: '-https://instagram.com/dresennn') ?></span>
      </a>

      <a class="list-group-item list-group-item-action d-flex align-items-center justify-content-between" href="<?= htmlspecialchars($gmailLink ?: '#') ?>">
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-envelope"></i>
          <span>Gmail</span>
        </div>
        <span class="text-muted" style="font-size:.9rem;"><?= htmlspecialchars($emailUser ?: 'jonatanandre01@gmail.com') ?></span>
      </a>
    </div>

  </div>
</div>
